package Proyecto.ONE;

public class Conversor {
    public double convertirMoneda(double cantidad, String monedaOrigen, String monedaDestino) {
        double tasaCambio = obtenerTasaCambio(monedaOrigen, monedaDestino);
        double cantidadConvertida = cantidad * tasaCambio;
        return cantidadConvertida;
    }

    private double obtenerTasaCambio(String monedaOrigen, String monedaDestino) {
        if (monedaOrigen.equals("USD") && monedaDestino.equals("EUR")) {
            return 0.91;
        } else if (monedaOrigen.equals("USD") && monedaDestino.equals("COP")) {
            return 4646.09;
        } else if (monedaOrigen.equals("EUR") && monedaDestino.equals("USD")) {
            return 1.18;
        } else if (monedaOrigen.equals("EUR") && monedaDestino.equals("COP")) {
            return 5110.19;
        } else if (monedaOrigen.equals("COP") && monedaDestino.equals("USD")) {
            return 0.00021;
        } else if (monedaOrigen.equals("COP") && monedaDestino.equals("EUR")) {
            return 0.000234;
        } else {
            throw new IllegalArgumentException("Las monedas ingresadas no son válidas");
        }
    }
}
