package Proyecto.ONE;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Conversor de Moneda");

        System.out.print("Cantidad: ");
        double cantidad = scanner.nextDouble();

        System.out.print("Moneda de origen (USD, EUR, COP): ");
        String monedaOrigen = scanner.next().toUpperCase();

        System.out.print("Moneda de destino (USD, EUR, COP): ");
        String monedaDestino = scanner.next().toUpperCase();

        Conversor conversor = new Conversor();
        double cantidadConvertida = conversor.convertirMoneda(cantidad, monedaOrigen, monedaDestino);

        System.out.printf("%.2f %s = %.2f %s", cantidad, monedaOrigen, cantidadConvertida, monedaDestino);

        scanner.close();
    }
}



